package com.bawei.jxcbiz.mapper;

import com.bawei.jxcbiz.entity.TCustomer;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Mht
 * @since 2020-02-20
 */
public interface TCustomerMapper extends BaseMapper<TCustomer> {

}
