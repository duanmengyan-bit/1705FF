package com.bawei.jxcbiz.service;

import com.bawei.jxcbiz.entity.TCustomer;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Mht
 * @since 2020-02-20
 */
public interface ITCustomerService extends IService<TCustomer> {

}
